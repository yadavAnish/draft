<?php ob_start();

$db['db_host'] = "localhost";
$db['db_user'] = "jjycbara";
$db['db_pass'] = "redhat@123";
$db['db_name'] = "jjycbara_cms";

foreach ($db as $key => $value) {
    if (!defined(strtoupper($key))) {
        define(strtoupper($key), $value);
    }
}

$connection = mysqli_connect(DB_HOST, DB_USER,DB_PASS,DB_NAME) or die("could not connect to server");

?>
